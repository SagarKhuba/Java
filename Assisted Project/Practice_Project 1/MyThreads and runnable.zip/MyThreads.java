package AssistedProjects;

public class MyThreads {
	public void start()
 	{
  		System.out.println("the  threaing was started running..");
}
 	public static void main( String args[] )
 	{
  		MyThreads mt = new  MyThreads();
  		mt.start();
 	}
}