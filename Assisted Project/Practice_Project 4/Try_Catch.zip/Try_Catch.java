package AssistedProjects;

import java.util.Scanner;

 class Try_Catch {
	 
	 Scanner scanner = new Scanner(System.in);
		
	    public static void main(String args[]) 
	    {
	        int[] array = new int[9];
	        try 
	        {
	            array[7] = 9;
	        }
	        catch (ArrayIndexOutOfBoundsException e) 
	        {
	            System.out.println("Array index is out of bounds!"); 
	        }
	        finally 
	        {
	            System.out.println("Display the array sizw " + array.length);
	        }
	    }
	}
	
