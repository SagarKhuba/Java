package orderstatics;

public class Main {
		public static void main(String[] args) {
			Smallest ob = new Smallest(); 
	        int arr[] = {12, 3, 5, 7, 4, 19, 26}; 
	        int n = arr.length,k = 4; 
	        System.out.println("K'th Smallest element is "+ ob.Small(arr, 0, n-1, k)); 
	    }
	}