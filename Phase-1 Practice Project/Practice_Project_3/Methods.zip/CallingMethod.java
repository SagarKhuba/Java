package Methods;

public class CallingMethod {
	int val=220;
	int operation(int val) {
val = val*35/100;
return(val);

}

	public static void main(String[] args) {
		CallingMethod s = new CallingMethod();
		System.out.println("Before operation value of data is "+s.val);
		s.operation(100);
		System.out.println("After operation value of data is "+s.val);
	}
	}