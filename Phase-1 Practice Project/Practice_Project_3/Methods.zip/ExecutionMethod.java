package Methods;

public class ExecutionMethod {
	public int multiplynumbers(int s,int t) {
		int z =s*t;
		return z;
	
	}
public static void main(String[] args) {
	ExecutionMethod t = new ExecutionMethod();
	int ans = t.multiplynumbers(17,18);
	System.out.println("Multiplication is:" +ans);
}
}