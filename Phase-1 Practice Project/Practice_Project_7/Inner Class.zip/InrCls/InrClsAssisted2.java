package InrCls;

public class InrClsAssisted2 {
	private String msg="Inner Classes";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.msg();  
	 }  

	 
	public static void main(String[] args) {
		InrClsAssisted2  ob=new InrClsAssisted2 ();  
		ob.display();  
		}
}