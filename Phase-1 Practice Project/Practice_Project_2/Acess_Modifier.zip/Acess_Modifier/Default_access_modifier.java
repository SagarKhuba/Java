package Acess_Modifier;

public class Default_access_modifier {
	void display() 
	   { 
	       System.out.println("Using defalut access specifier"); 
	   } 
		public static void main(String[] args) {
			//default
			System.out.println("Dafault Access Specifier");
			Default_access_modifier obj = new Default_access_modifier(); 		  
	        obj.display();

		}
	}
