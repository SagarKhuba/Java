package Acess_Modifier;

public class Public_Access_Specifier {
	void display() 
	   { 
	       System.out.println("Using protected access specifier"); 
	   } 
		public static void main(String[] args) {
			//public
			System.out.println("Protected Access Specifier");
			Protected_Access_Specifier obj = new Protected_Access_Specifier(); 		  
	        obj.display();
}
}